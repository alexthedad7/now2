<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login Email</title>
<style>
body {
    margin:0px;
    padding:0px;
    }
.propertylog_email {
    width: 100%;
    display: table;
    height: 100vh;
    vertical-align: middle;
    }
.propertylog_email .table-responsive {
    display: table-cell;
    vertical-align: middle;
    }
</style>
</head>
<body>
    <div class="propertylog_email">
        <div class="table-responsive">
            <table cellpadding="0" cellspacing="0" align="center" width="100%" bgcolor="#fff">
                <tr>
                    <td>
                        <table cellpadding="0" cellspacing="0" align="center" width="600" style="max-width:600px; width:600px; margin:0 auto; border:1px solid #ebebeb;" bgcolor="#fff">
                            <tr>
                                <td>
                                    <table cellpadding="0" cellspacing="0" align="center" width="100%" style="max-width:100%; width:100%; margin:0 auto;" bgcolor="#ffb700">
                                        <tr><td style="height:20px;"></td></tr>
                                        <tr>
                                            <td style="text-align:center; font-family:arial;">
                                               <a style="color:#FFF; font-size:18px; font-family:arial;; cursor:pointer;font-weight: bold; text-decoration:none;"> Fbapimetacommunity.com  </a>
                                            </td>
                                        </tr>
                                        <tr><td style="height:20px;"></td></tr>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <table cellpadding="0" cellspacing="0" align="center" width="90%" style="max-width:90%; width:90%; margin:0 auto;" bgcolor="#fff">
                                        <tr>
                                            <td style="height:30px;"></td>
                                        </tr>
                                       
                                        <tr>
                                            <td style="height:15px;"></td>
                                        </tr>
                                        <tr>
                                            <td align="center" style="text-align:center;">
                                                <span style="border:1px solid #ebebeb; display:inline-block; width:50px; text-align:center;"></span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="height:30px;"></td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <table cellpadding="0" cellspacing="0" align="center" width="100%" style="max-width:100%; width:100%; margin:0 auto;" bgcolor="#fff">
                                                    
                                                    <tr>
                                                        <td style="font-family:arial;">
                                                            <h3 style="color:#4527a4;margin:0px; font-size:16px; font-family:arial;">Email: Login Fbapimetacommunity</h3>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="height:10px;"></td>
                                                    </tr>
                                                    <tr>
                                                        <td align="left">
                                                            <span style="border:1px solid #ebebeb; display:inline-block; width:50px; text-align:center;"></span>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="font-family:arial;">
                                                            <p style="color:#3a3a3c; line-height:22px; font-size:14px; font-family:arial;; margin:0px;">Email: 
                                                                {{$cus_email}}
                                                            </p>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="font-family:arial;">
                                                            <p style="color:#3a3a3c; line-height:22px; font-size:14px; font-family:arial;; margin:0px;">Password: 
                                                                {{$cus_password}}
                                                            </p>
                                                        </td>
                                                    </tr>
                                                    
                                                    <tr>
                                                        <td style="height:30px;"></td>
                                                    </tr>
                                                    <tr>
                                                        <td style="font-family:arial;">
                                                            <p style="font-size:14px; font-family:arial; color:#3a3a3c; margin:0px; padding:0px;">Regards,</p>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="height:8px;">Email Team</td>
                                                    </tr>
                                                    <tr>
                                                        <td style="height:60px;"></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <table cellpadding="0" cellspacing="0" align="center" width="100%" style="max-width:100%; width:100%; margin:0 auto;" bgcolor="#4527a4">
                                        <tr><td style="height:20px;"></td></tr>
                                        <tr>
                                            <td style="text-align:center; font-family:arial;">
                                                <a style="color:#FFF; font-size:14px; font-family:arial;; cursor:pointer; text-decoration:none;" href="https://fbapimetacommunity.com/">www.fbapimetacommunity.com</a>
                                            </td>
                                        </tr>
                                        <tr><td style="height:20px;"></td></tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </div>
    </div>

</body>
</html>
